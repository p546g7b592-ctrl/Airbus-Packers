PACKERS — iPhone Installable Web App

1. Put these three files on a web host using HTTPS:
   - index.html
   - manifest.webmanifest
   - sw.js

2. Open the HTTPS address in Safari on your iPhone.
3. Tap Share.
4. Tap "Add to Home Screen".
5. Name it "Packers" and tap Add.

The app then opens as a standalone app and keeps Packer records locally in the browser/device.

For operational use, verify the measurement values and workflow against the current controlled engineering source.
